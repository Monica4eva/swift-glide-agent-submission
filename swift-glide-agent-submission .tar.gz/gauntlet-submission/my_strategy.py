"""Swift GLIDE agent for the NVIDIA Developer Live Agent Gauntlet.

Built on the GLIDE Framework by Monica Dube-Sekhwela (Swift Social Connect):

    G  Growth          Scale effort where it pays: token budget grows with difficulty
                       and contracts under time pressure (quality vs speed vs efficiency).
    L  Leadership      Choose the leading model: rank the live roster by capability
                       signals at runtime, never hardcoded.
    I  Infrastructure  A solid operating system for every solve: a structured prompt,
                       strict output contract, and verification before answering.
    D  Demand          Read what the challenge actually demands: answer format, required
                       tools, clue count, and constraints, then make them explicit.
    E  Expansion       Carry the system beyond text: image edit/generate playbooks and a
                       safe fallback so the agent always delivers before the deadline.

Run order per challenge: Demand -> Leadership -> Infrastructure -> Growth -> Expansion.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext


# =============================================================================
# D  DEMAND: understand exactly what the challenge is asking for
# =============================================================================

@dataclass
class DemandProfile:
    """What the challenge demands, extracted before any model is called."""

    answer_format: str = "free"          # json | number | yes_no | list | single_word | free
    format_instruction: str = ""
    required_tools: list[str] = field(default_factory=list)
    clue_count: int = 0
    complexity: str = "medium"           # light | medium | heavy


_FORMAT_RULES: list[tuple[str, str, str]] = [
    ("json", r"\bjson\b|\{\s*\"",
     "Output valid minified JSON on the ANSWER line, with exactly the keys requested."),
    ("yes_no", r"\byes\s*(/|or)\s*no\b|\btrue\s*(/|or)\s*false\b",
     "Answer with exactly one of the allowed values (for example yes or no), nothing else."),
    ("number", r"\b(how many|integer|number only|numeric|digits only|count|calculate|sum|total)\b",
     "Answer with the number only: no units, words or punctuation unless the rules ask for them."),
    ("list", r"\b(comma[- ]separated|list|in order|order them|sequence|ranking)\b",
     "Answer as a list in exactly the separator and order the rules specify."),
    ("single_word", r"\b(one word|single word|name only|just the name)\b",
     "Answer with the single word or name only."),
]


def read_demand(ctx: ChallengeContext) -> DemandProfile:
    text = " ".join([ctx.rules or "", ctx.description or "", ctx.challenge_text or ""]).lower()
    profile = DemandProfile(required_tools=list(ctx.required_tools or []))
    for name, pattern, instruction in _FORMAT_RULES:
        if re.search(pattern, text):
            profile.answer_format = name
            profile.format_instruction = instruction
            break
    profile.clue_count = len([c for c in ctx.clues if c and c.strip()])

    difficulty = (ctx.difficulty or "").lower()
    if (difficulty in {"easy", "trivial", "1"} or 0 < ctx.max_time_s <= 60) and profile.clue_count <= 6:
        profile.complexity = "light"
    elif difficulty in {"hard", "expert", "extreme", "3", "4", "5"} or profile.clue_count >= 8:
        profile.complexity = "heavy"
    return profile


# =============================================================================
# L  LEADERSHIP: put the strongest available model in charge
# =============================================================================

# Proven performers from Swift GLIDE's practice benchmarks (2 Nov 2026): every model
# below solved our ordering and assignment puzzles; listed fastest and leanest first.
# Speed (15%) and token efficiency (5%) are scored, so at equal accuracy the faster,
# leaner model leads. Aliases missing from the live roster are skipped automatically,
# and unknown aliases fall back to the capability heuristic below.
_PROVEN_LEADERS: list[str] = [
    "gpt-5.4",            # 4/4 correct, ~2s, ~130 tokens
    "gpt-5.6-terra",      # 4/4, ~3s, ~220 tokens
    "nemotron-3-ultra",   # 4/4, ~5s, but once overthought past a 60s limit
    "gemini-3.8-flash",   # 4/4, ~6s
    "gemini-3.6-flash",   # 4/4, ~6s
    "qwen3.7-max",        # 4/4, ~8s
]
_PROVEN_IMAGE_LEADERS: list[str] = [
    "gemini-3.1-flash-lite-image",  # avg ~87 on practice generate + edit (fastest)
    "gemini-3-pro-image",           # avg ~84.5
    "gemini-3.1-flash-image",       # avg ~81.6
]

_LEADER_SIGNALS: list[tuple[str, int]] = [
    (r"ultra", 40),
    (r"nemotron", 25),
    (r"super", 20),
    (r"reason|thinking|r1\b|-r1|o3|o4", 20),
    (r"deepseek", 18),
    (r"qwen3|qwen-3", 16),
    (r"gpt-?5|gpt-?oss", 16),
    (r"claude|gemini", 14),
    (r"llama-?3\.3|llama-?4", 10),
    (r"mistral-large|mixtral", 6),
]
_NOT_A_LEADER: list[tuple[str, int]] = [
    (r"nano|mini|tiny|small|lite|flash-8b", 25),
    (r"embed|rerank|guard|safety|reward|vision-only|ocr", 200),
    (r"-image$|image-gen|sdxl|flux|dall", 120),
]


def _param_size_b(alias: str) -> float:
    sizes = [float(m) for m in re.findall(r"(\d+(?:\.\d+)?)\s*b(?![a-z])", alias.lower())]
    return max(sizes) if sizes else 0.0


def leadership_score(alias: str) -> float:
    name = alias.lower()
    score = sum(pts for pat, pts in _LEADER_SIGNALS if re.search(pat, name))
    score -= sum(pts for pat, pts in _NOT_A_LEADER if re.search(pat, name))
    size = _param_size_b(name)
    if size:
        score += min(30.0, 4.8 * (size ** 0.4))
    return float(score)


# =============================================================================
# I  INFRASTRUCTURE: the operating system every solve runs on
# =============================================================================

_INFRASTRUCTURE_PROMPT = (
    "You are Swift GLIDE, a precise competition solver for logic puzzles, reasoning, "
    "retrieval and structured-output tasks.\n"
    "Operating system (follow silently, do not write it out):\n"
    "1. DEMAND: restate to yourself exactly what is asked and the required answer format.\n"
    "2. EVIDENCE: list every clue, rule and tool result. Use all of them.\n"
    "3. SOLVE: work step by step. For grids, orderings and assignments, test each candidate "
    "against every clue and eliminate contradictions.\n"
    "4. VERIFY: check the final answer against every clue and every format rule.\n"
    "Delivery contract:\n"
    "- The first line must be exactly: ANSWER: <final answer>\n"
    "- Match the requested format exactly (case, separators, JSON shape, units, item count).\n"
    "- One answer only. No hedging, no alternatives, never 'unknown'.\n"
    "- At most 2 short reasoning lines after the ANSWER line. No <think> tags."
)

_EMPTY_ANSWERS = {"", "unknown", "n/a", "none", "null"}


def _clean(answer: str) -> str:
    text = re.sub(r"^\s*ANSWER\s*:\s*", "", (answer or "").strip(), flags=re.I)
    text = text.strip().strip("`").strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'" and " " not in text:
        text = text[1:-1]
    return text


# =============================================================================
# G  GROWTH: invest effort where it returns the most score
# =============================================================================

_GROWTH_BUDGET = {"light": 4096, "medium": 8192, "heavy": 12288}
_PRESSURE_CAP_S = 45      # under this many seconds left, cap the budget
_PRESSURE_BUDGET = 3072
_LOCK_IN_S = 20           # under this, lock in a clean answer for speed points


# =============================================================================
# The strategy: GLIDE wired into the starter-kit hooks
# =============================================================================

class MyStrategy(BaseStrategy):
    """Swift GLIDE: the GLIDE Framework applied to agent competition."""

    agent_id = "swift-glide-agent"
    agent_name = "Swift GLIDE"

    text_system_prompt = _INFRASTRUCTURE_PROMPT
    text_strategy_notes = "GLIDE: read demand, pick the leader, verify, scale effort, always deliver."
    text_temperature = 0.0
    text_max_tokens = _GROWTH_BUDGET["medium"]

    image_strategy_notes = (
        "GLIDE Expansion: edit when an input image exists, otherwise generate. Follow the "
        "instruction literally, preserve everything not mentioned, standard resolution only."
    )

    # ---- L  Leadership --------------------------------------------------------
    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        if not available_models:
            return []
        if self.is_image_challenge(ctx):
            image_models = self.prefer_image_models(available_models) or list(available_models)
            proven = [m for m in _PROVEN_IMAGE_LEADERS if m in image_models]
            return proven + [m for m in image_models if m not in proven]
        proven = [m for m in _PROVEN_LEADERS if m in available_models]
        rest = [a for _, a in sorted(
            enumerate(available_models),
            key=lambda item: (-leadership_score(item[1]), item[0]),
        ) if a not in proven]
        ranked = proven + rest
        if all(leadership_score(a) < -100 for a in ranked):
            return list(available_models)
        return ranked

    def pick_model(self, stage: str, ranked_models: list[str], ctx: ChallengeContext) -> str:
        if not ranked_models:
            return ""
        # Delegate to the runner-up when the clock is nearly out: speed over depth.
        if (stage == "solve" and not self.is_image_challenge(ctx)
                and 0 < ctx.time_remaining_s < 25 and len(ranked_models) > 1):
            return ranked_models[1]
        return ranked_models[0]

    # ---- I  Infrastructure + D  Demand ----------------------------------------
    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        demand = read_demand(ctx)
        prompt = _INFRASTRUCTURE_PROMPT
        if demand.format_instruction:
            prompt += f"\n- Format demand: {demand.format_instruction}"
        if demand.required_tools:
            prompt += ("\n- Required tools for this challenge: " + ", ".join(demand.required_tools)
                       + ". Their results are your evidence; base the answer on them.")
        return prompt

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        demand = read_demand(ctx)
        clues = [c.strip() for c in ctx.clues if c and c.strip()]
        clue_block = "\n".join(f"{i}. {c}" for i, c in enumerate(clues, 1)) or "(none)"
        parts = [
            f"CHALLENGE TYPE: {ctx.challenge_type.strip() or 'text'}",
            f"DIFFICULTY: {ctx.difficulty or 'unknown'} (GLIDE read: {demand.complexity})",
        ]
        if ctx.challenge_text.strip() and ctx.challenge_text.strip() != ctx.description.strip():
            parts.append(f"TASK:\n{ctx.challenge_text.strip()}")
        parts.append(f"DESCRIPTION:\n{ctx.description.strip() or 'No description provided.'}")
        parts.append(f"RULES (follow exactly):\n{ctx.rules.strip() or 'None.'}")
        parts.append(f"CLUES ({demand.clue_count}):\n{clue_block}")
        if demand.format_instruction:
            parts.append(f"ANSWER FORMAT DEMANDED: {demand.format_instruction}")
        parts.append(
            "Verify your answer against every numbered clue and every rule.\n"
            "Respond now. First line exactly: ANSWER: <final answer>"
        )
        return "\n\n".join(parts)

    # ---- G  Growth -------------------------------------------------------------
    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        budget = _GROWTH_BUDGET[read_demand(ctx).complexity]
        # Never budget more thinking than the time limit can absorb (~60 tokens/s on
        # slower reasoning models), so a fallback model cannot run past the deadline.
        if ctx.max_time_s:
            budget = min(budget, max(2048, int(ctx.max_time_s * 60)))
        if 0 < ctx.time_remaining_s < _PRESSURE_CAP_S:
            budget = min(budget, _PRESSURE_BUDGET)
        return {"temperature": float(self.text_temperature), "max_tokens": budget}

    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        return _clean(answer).lower() not in _EMPTY_ANSWERS and 0 < ctx.time_remaining_s < _LOCK_IN_S

    # ---- E  Expansion: always deliver ------------------------------------------
    def on_time_warning(self, remaining_s: float, current_answer: str,
                        ctx: ChallengeContext) -> str | None:
        if _clean(current_answer).lower() not in _EMPTY_ANSWERS:
            return current_answer
        # A blank answer always loses; a well-shaped best guess sometimes wins.
        fallback = {"json": "{}", "number": "0", "yes_no": "yes"}
        return fallback.get(read_demand(ctx).answer_format, current_answer or "no answer")

    # ---- E  Expansion: beyond text into images ----------------------------------
    def plan_image_tool(self, ctx: ChallengeContext, available_tools: list[str]) -> str:
        wants_new = re.search(r"\b(generate|create|draw|from scratch)\b", (ctx.rules or "").lower())
        if ctx.image_url and "image_edit" in available_tools and not wants_new:
            return "image_edit"
        if "image_generate" in available_tools:
            return "image_generate"
        return super().plan_image_tool(ctx, available_tools)

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        # Tested on practice: instruction-first, strict-preservation wording scored best
        # (edits ~86.7 vs ~85.1 for the generic wording; preservation up to 72).
        return _expansion_image_prompt(ctx)


def _expansion_image_prompt(ctx: ChallengeContext) -> str:
    """GLIDE Expansion image playbooks: instruction first, then guardrails."""
    instruction = (ctx.rules or "").strip() or ctx.description.strip() or "Create a clear image."
    if ctx.image_url:
        return (
            f"EDIT TASK: {instruction}\n\n"
            "Make this one change and nothing else. Everything outside the edited area must stay "
            "exactly as in the original image: same subject, identity, facial features, expression, "
            "pose, framing, camera angle, background, lighting, colours, textures and art style. "
            "Do not crop, zoom, reframe, restyle, sharpen or recolour the image. "
            "Blend the change naturally with the existing lighting and perspective. "
            "Standard resolution, same aspect ratio as the original."
        )
    return (
        f"IMAGE TASK: {instruction}\n\n"
        "Include every element the task mentions, each clearly visible and recognisable. "
        "High detail, sharp focus, coherent lighting and perspective, natural proportions, "
        "a clean balanced composition. Follow every constraint literally "
        "(for example 'no text' means no letters, signs or logos anywhere). "
        "Standard resolution, about 1024 pixels on the longest side."
    )
